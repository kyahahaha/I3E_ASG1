using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InventoryManager : MonoBehaviour
{
    public GameObject inventoryPanel;
    public List<string> items = new List<string>();
    public Text itemListText; // Link to a UI Text that lists item names

    void Start()
    {
        inventoryPanel.SetActive(false);
        UpdateInventoryUI();
    }

    void Update()
    {
        // Toggle inventory with "I"
        if (Input.GetKeyDown(KeyCode.I))
        {
            inventoryPanel.SetActive(!inventoryPanel.activeSelf);
            UpdateInventoryUI();
        }
    }

    public void AddItem(string itemName)
    {
        items.Add(itemName);
        UpdateInventoryUI();
    }

    void UpdateInventoryUI()
    {
        if (itemListText == null) return;

        itemListText.text = "";
        foreach (string item in items)
        {
            itemListText.text += "- " + item + "\n";
        }
    }
}
