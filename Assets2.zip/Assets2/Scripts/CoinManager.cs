using UnityEngine;

public class CoinManager : MonoBehaviour
{
    public static CoinManager Instance;

    public int coinCount = 0;

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    public void AddCoin()
    {
        coinCount++;
        Debug.Log("Coins: " + coinCount);
    }

    public bool HasEnoughCoins(int amount)
    {
        return coinCount >= amount;
    }
}
