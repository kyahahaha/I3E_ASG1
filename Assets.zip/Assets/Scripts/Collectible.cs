using UnityEngine;

public class Collectibles : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            other.GetComponent<PlayerInventory>().AddCoin();
            Destroy(gameObject);
        }
    }
}
