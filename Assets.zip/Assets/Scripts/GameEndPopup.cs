using UnityEngine;

public class GameEndPopup : MonoBehaviour
{
    public GameObject gameCompletePopup;

    void Start()
    {
        if (gameCompletePopup != null)
            gameCompletePopup.SetActive(false); // Hide at start
    }
    void OnTriggerEnter(Collider other)
{
    if (other.CompareTag("Player"))
    {
        // Show the popup
        FindFirstObjectByType<GameEndPopup>().ShowPopup();

    }
}


    public void ShowPopup()
    {
        if (gameCompletePopup != null)
            gameCompletePopup.SetActive(true); // Show when called
    }
}
