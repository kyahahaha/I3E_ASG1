using UnityEngine;

public class PlayerInventory : MonoBehaviour
{
    public int coinCount = 0;
    public bool hasRedKeycard = false;
    public bool hasBlackKeycard = false;

    public void AddCoin()
    {
        coinCount++;
        Debug.Log("Coins: " + coinCount);
        UIManager.Instance.UpdateCoinText(coinCount);
    }

    public void AddKeycard(string color)
    {
        if (color == "Red")
        {
            hasRedKeycard = true;
            Debug.Log("Picked up Red Keycard");
        }
        else if (color == "Blue")
        {
            hasBlackKeycard = true;
            Debug.Log("Picked up Blue Keycard");
        }

        UIManager.Instance.UpdateKeycards(hasRedKeycard, hasBlackKeycard);
    }
}
