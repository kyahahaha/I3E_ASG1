using UnityEngine;
using TMPro;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    public TextMeshProUGUI coinText;
    public TextMeshProUGUI keycardText;

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    public void UpdateCoinText(int coins)
    {
        if (coinText != null)
            coinText.text = "Coins: " + coins;
    }

    public void UpdateKeycards(bool red, bool blue)
    {
        if (keycardText != null)
        {
            string text = "Keycards: ";
            if (red) text += "[Red] ";
            if (blue) text += "[Blue]";
            keycardText.text = text;
        }
    }
}
